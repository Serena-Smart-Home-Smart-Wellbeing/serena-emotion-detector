#!/usr/bin/env python
# coding: utf-8

# # Saving Model

# In[ ]:


model.save('/gcs/serena-shsw-datasets/models/emotion-detector')

