# How to Train in Vertex AI
1. Run setup.sh
2. 